async function loginWithFingerprint() {
    const email = document.getElementById('email').value;
    if (!email) {
        alert('Please enter your email');
        return;
    }

    try {
        // Fetch the challenge and credential ID from the server
        const challengeResponse = await fetch('/get-challenge', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email: email })
        });
        
        const { challenge, credentialId } = await challengeResponse.json();

        // PublicKeyCredentialRequestOptions for WebAuthn
        const publicKeyCredentialRequestOptions = {
            challenge: new Uint8Array(challenge), // Server-generated challenge
            allowCredentials: [{
                type: "public-key",
                id: new Uint8Array(credentialId), // Server-stored credential ID
                transports: ["usb", "nfc", "ble", "internal"]
            }]
        };

        // Get WebAuthn Assertion
        const assertion = await navigator.credentials.get({
            publicKey: publicKeyCredentialRequestOptions
        });

        // Send the assertion back to the server for verification
        const response = await fetch('/verify-assertion', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: email,
                assertion: assertion // WebAuthn assertion response
            })
        });

        const result = await response.json();
        if (result.success) {
            alert('Login successful!');
            localStorage.setItem('loggedInUser', 'true'); // Store login session
            window.location.href = 'dashboard.html'; // Redirect to the dashboard
        } else {
            alert('Login failed!');
        }
    } catch (err) {
        console.error(err);
        alert('Error with fingerprint login.');
    }
}
