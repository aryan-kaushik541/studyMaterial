const mysql = require('mysql');

// Database configuration
const dbConfig = {
    host: 'localhost',
    user: 'root',  // Your MySQL username
    password: '',  // Your MySQL password
    database: 'login_system'
};

module.exports = dbConfig;
