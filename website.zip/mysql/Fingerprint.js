const db = require('./db');

// Authenticate user with fingerprint data
async function authenticateUserWithFingerprint(email, fingerprintHash) {
    const query = 'SELECT * FROM users WHERE email = ?';

    db.query(query, [email], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return;
        }

        if (results.length === 0) {
            console.log('No user found with this email.');
            return;
        }

        const user = results[0];

        // Compare the provided fingerprint hash with the one in the database
        if (user.fingerprint_data === fingerprintHash) {
            console.log('Fingerprint authentication successful.');
        } else {
            console.log('Fingerprint authentication failed.');
        }
    });
}

module.exports = { authenticateUserWithFingerprint };
